<?php
$file = "allcv/".$_REQUEST['file'];

$handle = fopen($file, 'r');
$data = fread($handle,filesize($file));

include('converter/fpdf/fpdf.php');
$pdf=new FPDF();
//$pdf->WriteHtml($file);
$pdf->AddPage($file);
$pdf->Output(); 
//fclose($handle);  
//header('location:savedCv.php');
 ?>