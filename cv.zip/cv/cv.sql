-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 24, 2018 at 12:04 AM
-- Server version: 10.1.31-MariaDB-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- Database: `fksitesc_prizebond`
--

-- --------------------------------------------------------

--
-- Table structure for table `allcv`
--

CREATE TABLE `allcv` (
  `id` int(11) NOT NULL,
  `cvName` varchar(1111) NOT NULL,
  `cvFileName` varchar(1111) NOT NULL,
  `userId` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `allcv`
--

INSERT INTO `allcv` (`id`, `cvName`, `cvFileName`, `userId`, `date`) VALUES
(5, 'my new cv', '1514693712-1', 1, '2017-12-31 04:15:12'),
(7, 'No Name', '1515132458-1', 1, '2018-01-05 06:07:39'),
(8, 'asdf', '1515132464-1', 1, '2018-01-05 06:07:44'),
(9, 'newCV', '1522486636-4', 4, '2018-03-31 08:57:16'),

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(111) NOT NULL,
  `password` varchar(111) NOT NULL,
  `name` varchar(111) NOT NULL,
  `dbdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `dbdate`) VALUES
(1, 'PARVSQAUD', '123456', 'PARV SQUAD', '2017-10-13 12:24:45'),
(2, 'kashi', 'kashi', 'ROSHAN', '2017-10-13 13:49:39'),
(3, 'fk@solply', 'solply786', 'some', '2018-02-07 08:26:42'),
(4, 'fk', 'fk', 'VIVEK', '2018-03-31 08:55:36'),
(5, 'prieto', 'prieto', 'Prieto Ana', '2018-07-14 15:17:17'),

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allcv`
--
ALTER TABLE `allcv`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allcv`
--
ALTER TABLE `allcv`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
